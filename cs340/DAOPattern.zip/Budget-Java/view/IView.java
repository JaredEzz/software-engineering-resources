package view;

public interface IView {
    void start(Object args);
}
